const readline = require("readline");

// Clase Producto: Representa cada producto disponible
class Producto {
    constructor(nombre, precio) {
        this.nombre = nombre;
        this.precio = precio;
    }

    // Método para mostrar información del producto
    mostrarInfo() {
        return `${this.nombre} (S/${this.precio.toFixed(2)})`;
    }
}

// Clase Carrito: Maneja los productos seleccionados y cálculos
class Carrito {
    constructor() {
        this.productos = [];
    }

    // Agregar un producto al carrito
    agregarProducto(producto) {
        this.productos.push(producto);
        return producto;
    }

    // Calcular el total sin descuentos
    calcularTotal() {
        return this.productos.reduce((total, p) => total + p.precio, 0);
    }

    // Aplicar descuento según el monto total
    aplicarDescuento() {
        const total = this.calcularTotal();
        let descuento = 0;
        
        if (total > 50) {
            descuento = total * 0.1;
        } else if (total >= 20) {
            descuento = total * 0.05;
        }
        
        return {
            total,
            descuento,
            totalFinal: total - descuento
        };
    }

    // Mostrar el contenido del carrito
    mostrarContenido() {
        return this.productos.map((p, i) => `${i + 1}. ${p.mostrarInfo()}`).join('\n');
    }
}

// Clase SistemaVentas: Controla el flujo principal
class SistemaVentas {
    constructor() {
        this.productosDisponibles = [
            new Producto("pan", 2.0),
            new Producto("leche", 3.5),
            new Producto("queso", 7.0),
            new Producto("galletas", 4.0),
            new Producto("Gaseosa", 4.0)
        ];
        
        this.carrito = new Carrito();
        this.rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });
    }

    // Iniciar el proceso de compra
    iniciarCompra() {
        console.log("🛒 BIENVENIDO AL SISTEMA DE VENTAS POO 🛒");
        this.mostrarProductos();
        this.pedirProducto();
    }

    // Mostrar productos disponibles
    mostrarProductos() {
        console.log("\nProductos disponibles:");
        this.productosDisponibles.forEach(p => {
            console.log(`- ${p.mostrarInfo()}`);
        });
    }

    // Pedir productos al usuario
    pedirProducto() {
        this.rl.question("\n¿Qué producto deseas comprar? (escribe 'salir' para terminar): ", respuesta => {
            if (respuesta.toLowerCase() === 'salir') {
                this.finalizarCompra();
            } else {
                this.procesarProducto(respuesta);
            }
        });
    }

    // Procesar la entrada del usuario para agregar productos
    procesarProducto(nombre) {
        const producto = this.productosDisponibles.find(p => 
            p.nombre.toLowerCase() === nombre.toLowerCase()
        );

        if (producto) {
            const productoAgregado = this.carrito.agregarProducto(producto);
            console.log(`✅ ${productoAgregado.nombre} agregado al carrito.`);
        } else {
            console.log("❌ Producto no encontrado. Intenta con otro.");
        }

        this.pedirProducto();
    }

    // Finalizar la compra y mostrar resumen
    finalizarCompra() {
        const { total, descuento, totalFinal } = this.carrito.aplicarDescuento();
        
        console.log("\n🧾 RESUMEN DE COMPRA:");
        console.log(this.carrito.mostrarContenido());
        console.log(`\nTotal antes de descuento: S/${total.toFixed(2)}`);
        console.log(`Descuento aplicado: S/${descuento.toFixed(2)}`);
        console.log(`Total a pagar: S/${totalFinal.toFixed(2)}`);
        console.log("¡Gracias por su compra! 🛒");
        
        this.rl.close();
    }
}

// Iniciar el sistema
const sistema = new SistemaVentas();
sistema.iniciarCompra();